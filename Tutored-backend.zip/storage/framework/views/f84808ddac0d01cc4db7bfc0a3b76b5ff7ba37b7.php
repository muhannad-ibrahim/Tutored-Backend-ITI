<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\ITI\tasks\Projects\Graduation-Project\Tutored-Backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>